package com.example.conversiones;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void convertir(View view) {
        EditText inputEditText = findViewById(R.id.inputEditText);
        EditText outputEditText = findViewById(R.id.outputEditText);
        Spinner inputSpinner = findViewById(R.id.inputSpinner);
        Spinner outputSpinner = findViewById(R.id.outputSpinner);

        String inputUnit = inputSpinner.getSelectedItem().toString();
        String outputUnit = outputSpinner.getSelectedItem().toString();

        String inputString = inputEditText.getText().toString().trim();
        if (inputString.isEmpty()) {
            Toast.makeText(this, "Ingresa un valor", Toast.LENGTH_SHORT).show();
            return;
        }

        double inputValue;
        try {
            inputValue = Double.parseDouble(inputString);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingresa un valor válido", Toast.LENGTH_SHORT).show();
            return;
        }

// Realiza la conversión y establece el valor en el campo de salida
        try {
            double outputValue = convertirUnidades(inputUnit, outputUnit, inputValue);
            outputEditText.setText(String.format(Locale.getDefault(), "%.2f", outputValue));
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            return;
        }
    }

    private double convertirUnidades(String inputUnit, String outputUnit, double inputValue) {
        double outputValue;

        if (inputUnit.equals(outputUnit)) {
            outputValue = inputValue;
        } else if (inputUnit.equals("Metro") && outputUnit.equals("Pie")) {
            outputValue = inputValue * 3.28084;
        } else if (inputUnit.equals("Pie") && outputUnit.equals("Metro")) {
            outputValue = inputValue / 3.28084;
        } else if (inputUnit.equals("Kilogramo") && outputUnit.equals("Libra")) {
            outputValue = inputValue * 2.20462;
        } else if (inputUnit.equals("Libra") && outputUnit.equals("Kilogramo")) {
            outputValue = inputValue / 2.20462;
        } else if (inputUnit.equals("Litro") && outputUnit.equals("Galón")) {
            outputValue = inputValue * 0.264172;
        } else if (inputUnit.equals("Galón") && outputUnit.equals("Litro")) {
            outputValue = inputValue / 0.264172;
        } else if (inputUnit.equals("Celsius") && outputUnit.equals("Fahrenheit")) {
            outputValue = (inputValue * 9 / 5) + 32;
        } else if (inputUnit.equals("Fahrenheit") && outputUnit.equals("Celsius")) {
            outputValue = (inputValue - 32) * 5 / 9;
        } else {
            throw new IllegalArgumentException("Unidades no válidas");
        }

        return outputValue;
    }
}